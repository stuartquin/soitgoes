var searchData=
[
  ['pdfglobal',['PdfGlobal',['../structwkhtmltopdf_1_1settings_1_1PdfGlobal.html',1,'wkhtmltopdf::settings']]],
  ['pdfobject',['PdfObject',['../structwkhtmltopdf_1_1settings_1_1PdfObject.html',1,'wkhtmltopdf::settings']]]
];
