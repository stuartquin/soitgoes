var searchData=
[
  ['width',['width',['../structwkhtmltopdf_1_1settings_1_1Size.html#ad071ed934cb5f0347d287b09d633c29a',1,'wkhtmltopdf::settings::Size::width()'],['../structwkhtmltopdf_1_1settings_1_1CropSettings.html#a62409ce4f86d51bea9242b8e684c6373',1,'wkhtmltopdf::settings::CropSettings::width()']]]
];
