var searchData=
[
  ['setting',['Setting',['../pagesettings.html',1,'']]]
];
